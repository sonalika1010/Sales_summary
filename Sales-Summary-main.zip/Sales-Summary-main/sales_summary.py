
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt

# Connect to the SQLite database
conn = sqlite3.connect("sales_data.db")

# SQL query to get sales summary
query = """
SELECT 
    product, 
    SUM(quantity) AS total_qty, 
    SUM(quantity * price) AS revenue 
FROM sales 
GROUP BY product
"""

# Load query results into a DataFrame
df = pd.read_sql_query(query, conn)

# Print the results
print("Sales Summary:")
print(df)

# Plot a bar chart of revenue by product
plt.figure(figsize=(8, 5))
df.plot(kind='bar', x='product', y='revenue', legend=False, color='skyblue')
plt.title('Revenue by Product')
plt.ylabel('Revenue')
plt.tight_layout()

# Save the chart
plt.savefig("sales_chart.png")

# Close the connection
conn.close()
